// s1 outfit
let s1 = /* get #s1 outfit */
/* the process: */
s1.onclick = function() {
	/* 1. hide #body (set display to none)
	/* 2. call the function you created to hide all the outfits 
	(remember: get the list of .outfit elements and use a for loop to hide each outfit)
	/* 3. show #o1 outfit (set display to block)*/
};

// s2 outfit
/* get #s2 outfit */
/* repeat process */

// s3 outfit
/* get #s3 outfit */
/* repeat process */

// s4 outfit
/* get #s4 outfit */
/* repeat process */

// s5 outfit
/* get #s5 outfit */
/* repeat process */

// strip outfit
let strip = /* get #strip-button */
strip.onclick = function() {
	/* call the function you created to hide all the outfits */
	/* show #body */
};